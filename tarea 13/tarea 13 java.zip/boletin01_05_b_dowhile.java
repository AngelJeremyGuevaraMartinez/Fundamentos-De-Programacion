import javax.swing.*;

public class boletin01_05_b_dowhile {
    public static void main(String[] args) throws Exception {
        // Ejercicio 5: Decir si un número es positivo o negativo
        // Variante: JOptionPane + do while

        int i = 0;


        do{

            // Aquí puedes implementar la lógica del ejercicio
            String s = JOptionPane.showInputDialog("Introduce un valor"); JOptionPane.showMessageDialog(null,"Valor leído: "+s);
            i++;

        }while(i<1);

    }
}
