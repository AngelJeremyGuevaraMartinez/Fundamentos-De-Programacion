import javax.swing.*;

public class boletin01_07_b_dowhile {
    public static void main(String[] args) throws Exception {
        // Ejercicio 7: Decir cuál de dos números es mayor
        // Variante: JOptionPane + do while

        int i = 0;


        do{

            // Aquí puedes implementar la lógica del ejercicio
            String s = JOptionPane.showInputDialog("Introduce un valor"); JOptionPane.showMessageDialog(null,"Valor leído: "+s);
            i++;

        }while(i<1);

    }
}
