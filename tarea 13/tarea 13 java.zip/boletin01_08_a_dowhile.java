import java.io.*;

public class boletin01_08_a_dowhile {
    public static void main(String[] args) throws Exception {
        // Ejercicio 8: Decir cuál de dos números es mayor o si son iguales
        // Variante: BufferedReader + do while

        int i = 0;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        do{

            // Aquí puedes implementar la lógica del ejercicio
            System.out.println("Introduce un valor:"); int x = Integer.parseInt(br.readLine()); System.out.println("Valor leído: "+x);
            i++;

        }while(i<1);

    }
}
