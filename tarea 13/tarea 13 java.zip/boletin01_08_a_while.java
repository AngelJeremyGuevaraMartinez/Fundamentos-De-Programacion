import java.io.*;

public class boletin01_08_a_while {
    public static void main(String[] args) throws Exception {
        // Ejercicio 8: Decir cuál de dos números es mayor o si son iguales
        // Variante: BufferedReader + while

        int i = 0;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        while(i < 1) {

            // Aquí puedes implementar la lógica del ejercicio
            System.out.println("Introduce un valor:"); int x = Integer.parseInt(br.readLine()); System.out.println("Valor leído: "+x);
            i++;

        }

    }
}
