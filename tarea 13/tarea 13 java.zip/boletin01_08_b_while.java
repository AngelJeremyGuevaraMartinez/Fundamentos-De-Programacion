import javax.swing.*;

public class boletin01_08_b_while {
    public static void main(String[] args) throws Exception {
        // Ejercicio 8: Decir cuál de dos números es mayor o si son iguales
        // Variante: JOptionPane + while

        int i = 0;


        while(i < 1) {

            // Aquí puedes implementar la lógica del ejercicio
            String s = JOptionPane.showInputDialog("Introduce un valor"); JOptionPane.showMessageDialog(null,"Valor leído: "+s);
            i++;

        }

    }
}
