import java.io.*;

public class boletin01_09_a_dowhile {
    public static void main(String[] args) throws Exception {
        // Ejercicio 9: Ordenar dos números de mayor a menor
        // Variante: BufferedReader + do while

        int i = 0;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        do{

            // Aquí puedes implementar la lógica del ejercicio
            System.out.println("Introduce un valor:"); int x = Integer.parseInt(br.readLine()); System.out.println("Valor leído: "+x);
            i++;

        }while(i<1);

    }
}
