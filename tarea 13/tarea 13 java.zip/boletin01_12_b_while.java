import javax.swing.*;

public class boletin01_12_b_while {
    public static void main(String[] args) throws Exception {
        // Ejercicio 12: Mostrar un número al revés
        // Variante: JOptionPane + while

        int i = 0;


        while(i < 1) {

            // Aquí puedes implementar la lógica del ejercicio
            String s = JOptionPane.showInputDialog("Introduce un valor"); JOptionPane.showMessageDialog(null,"Valor leído: "+s);
            i++;

        }

    }
}
