import java.io.*;

public class boletin01_13_a_for {
    public static void main(String[] args) throws Exception {
        // Ejercicio 13: Decir si un número es capicúa
        // Variante: BufferedReader + for

        int i = 0;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        for(i=0;i<1;i++){

            // Aquí puedes implementar la lógica del ejercicio
            System.out.println("Introduce un valor:"); int x = Integer.parseInt(br.readLine()); System.out.println("Valor leído: "+x);
            i++;

        }

    }
}
