import javax.swing.*;

public class boletin01_14_b_for {
    public static void main(String[] args) throws Exception {
        // Ejercicio 14: Mostrar nota como texto (Insuficiente, etc.)
        // Variante: JOptionPane + for

        int i = 0;


        for(i=0;i<1;i++){

            // Aquí puedes implementar la lógica del ejercicio
            String s = JOptionPane.showInputDialog("Introduce un valor"); JOptionPane.showMessageDialog(null,"Valor leído: "+s);
            i++;

        }

    }
}
