import java.io.*;

public class boletin01_15_a_while {
    public static void main(String[] args) throws Exception {
        // Ejercicio 15: Validar fecha suponiendo meses de 30 días
        // Variante: BufferedReader + while

        int i = 0;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        while(i < 1) {

            // Aquí puedes implementar la lógica del ejercicio
            System.out.println("Introduce un valor:"); int x = Integer.parseInt(br.readLine()); System.out.println("Valor leído: "+x);
            i++;

        }

    }
}
