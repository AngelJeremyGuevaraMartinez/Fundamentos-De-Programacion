
Algoritmo boletin01_01
    // Resolver ecuación de segundo grado
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
