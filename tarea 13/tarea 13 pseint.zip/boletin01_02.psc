
Algoritmo boletin01_02
    // Calcular área de un círculo
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
