
Algoritmo boletin01_03
    // Calcular longitud de una circunferencia
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
