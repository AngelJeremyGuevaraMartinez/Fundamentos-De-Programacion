
Algoritmo boletin01_04
    // Decir si dos números son iguales
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
