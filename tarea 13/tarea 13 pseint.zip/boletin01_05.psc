
Algoritmo boletin01_05
    // Decir si un número es positivo o negativo
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
