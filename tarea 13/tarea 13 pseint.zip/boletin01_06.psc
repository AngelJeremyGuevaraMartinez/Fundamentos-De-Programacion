
Algoritmo boletin01_06
    // Decir si un número es múltiplo de otro
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
