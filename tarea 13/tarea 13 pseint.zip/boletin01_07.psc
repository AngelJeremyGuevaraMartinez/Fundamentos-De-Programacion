
Algoritmo boletin01_07
    // Decir cuál de dos números es mayor
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
