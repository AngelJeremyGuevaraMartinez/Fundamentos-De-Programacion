
Algoritmo boletin01_08
    // Decir cuál de dos números es mayor o si son iguales
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
