
Algoritmo boletin01_09
    // Ordenar dos números de mayor a menor
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
