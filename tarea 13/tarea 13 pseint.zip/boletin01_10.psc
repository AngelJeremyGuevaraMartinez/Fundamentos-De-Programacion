
Algoritmo boletin01_10
    // Ordenar tres números de mayor a menor
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
