
Algoritmo boletin01_11
    // Decir cuántas cifras tiene un número (0–99999)
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
