
Algoritmo boletin01_12
    // Mostrar un número al revés
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
