
Algoritmo boletin01_13
    // Decir si un número es capicúa
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
