
Algoritmo boletin01_14
    // Mostrar nota como texto (Insuficiente, etc.)
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
