
Algoritmo boletin01_15
    // Validar fecha suponiendo meses de 30 días
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
