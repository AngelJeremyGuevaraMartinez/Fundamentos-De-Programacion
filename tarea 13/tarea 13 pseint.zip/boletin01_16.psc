
Algoritmo boletin01_16
    // Validar fecha con meses de 28,30,31
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
