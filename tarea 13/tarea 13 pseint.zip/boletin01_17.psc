
Algoritmo boletin01_17
    // Mostrar el día siguiente de una fecha
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
