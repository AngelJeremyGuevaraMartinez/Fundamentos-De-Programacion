
Algoritmo boletin01_18
    // Día siguiente considerando días reales del mes
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
