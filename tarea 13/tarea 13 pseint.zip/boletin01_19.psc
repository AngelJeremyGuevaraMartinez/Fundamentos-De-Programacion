
Algoritmo boletin01_19
    // Diferencia de días entre dos fechas
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
