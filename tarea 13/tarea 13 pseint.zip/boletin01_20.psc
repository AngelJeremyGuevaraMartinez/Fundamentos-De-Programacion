
Algoritmo boletin01_20
    // Mostrar la hora del segundo siguiente
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
