
Algoritmo boletin01_21
    // Mostrar nota numérica escrita (cero, uno,...)
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
