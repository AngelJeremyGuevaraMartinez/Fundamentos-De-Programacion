
Algoritmo boletin01_22
    // Mostrar número de 0 a 99 escrito
    Definir x Como Entero

    Escribir "Introduce un valor:"
    Leer x

    Escribir "Valor ingresado:", x
FinAlgoritmo
