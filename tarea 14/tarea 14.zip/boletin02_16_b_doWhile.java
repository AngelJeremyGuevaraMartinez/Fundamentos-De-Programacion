package tarea14;
import javax.swing.JOptionPane;
public class boletin02_16_b_doWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num, i;
		do {
			num = Integer.parseInt(JOptionPane.showInputDialog("introduce un numero de 0 a 10"));
		} while (num < 0 || num >= 10);
		for (i = 1; i <= 10; i++) {
			JOptionPane.showMessageDialog(null, num + "x" + i + "=" + num * i);
		}
		

	}

}
