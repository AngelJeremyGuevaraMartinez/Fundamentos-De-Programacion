package tarea14;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class boletin02_17_a_for {

	public static void main(String[] args)  throws IOException {
		// TODO Auto-generated method stub
		int i, codigo, litros, mas_600, litros_cod1;
		double precio, importe_factura, facturacion_total;
		facturacion_total = 0;
		litros_cod1 = 0;
		mas_600 = 0;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		for (i = 1; i <= 5; i++) {
			System.out.println("Factura No " + i);
			System.out.println("Codigo de producto: ");
			codigo = Integer.parseInt(br.readLine());
			System.out.println("Cantidad (litros): ");
			litros = Integer.parseInt(br.readLine());
			System.out.println("Precio por litro: ");
			precio = Double.parseDouble(br.readLine());
			importe_factura = litros * precio;
			facturacion_total = facturacion_total + importe_factura;
			if (codigo == 1) {
				litros_cod1 = litros_cod1 + litros;
			}
			if (importe_factura >= 600) {
				mas_600 = mas_600 + 1;
			}
		}
		System.out.println("Facturacion total: " + facturacion_total);
		System.out.println("Litros vendidos del producto 1: " + litros_cod1);
		System.out.println("Facturas mayores a 600: " + mas_600);
		
		
		

	}

}
