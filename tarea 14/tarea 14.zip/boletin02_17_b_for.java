package tarea14;
import javax.swing.JOptionPane;

public class boletin02_17_b_for {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, codigo, litros, mas_600 = 0, litros_cod1 = 0;
		double precio, importe_factura, facturacion_total;
		facturacion_total = 0;
		
		for (i = 1; i <= 5; i++) {
			JOptionPane.showMessageDialog(null, "Factura No " + i);
			codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo de producto: "));
			litros = Integer.parseInt(JOptionPane.showInputDialog("Cantidad (litros): "));
			precio = Double.parseDouble(JOptionPane.showInputDialog("Precio por litro: "));
			importe_factura = litros * precio;
			facturacion_total = facturacion_total + importe_factura;
			if (codigo == 1) {
				litros_cod1 = litros_cod1 + litros;
			}
			if (importe_factura >= 600) {
				mas_600 = mas_600 + 1;
			}
		}
		JOptionPane.showMessageDialog(null, "Facturacion total: " + facturacion_total);
		JOptionPane.showMessageDialog(null, "Litros vendidos del producto 1: " + litros_cod1);
		JOptionPane.showMessageDialog(null, "Facturas mayores a 600: " + mas_600);
		

	}

}
