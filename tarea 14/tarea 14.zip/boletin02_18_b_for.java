package tarea14;
import javax.swing.JOptionPane;

public class boletin02_18_b_for {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, codigo, litros, litros_cod1, mas_600;
		double precio, importe_factura, facturacion_total;
		facturacion_total = 0;
		litros_cod1 = 0;
		mas_600 = 0;
		for (i = 1; i <= 5; i++) {
			codigo = Integer.parseInt(JOptionPane.showInputDialog("Codigo de producto: "));
			litros = Integer.parseInt(JOptionPane.showInputDialog("Cantidad (litros): "));
			switch (codigo) {
			case 1:
				precio = 0.6;
				break;
			case 2:
				precio = 3;
				break;
			case 3:
				precio = 1.25;
				break;
			default:
				precio = 0;
			}
			importe_factura = litros * precio;
			facturacion_total = facturacion_total + importe_factura;
			if (codigo == 1) {
				litros_cod1 = litros_cod1 + litros;
			}
			if (importe_factura >= 600) {
				mas_600 = mas_600 + 1;
			}
		}
		JOptionPane.showMessageDialog(null, "Facturacion total: " + facturacion_total);
		JOptionPane.showMessageDialog(null, "Litros vendidos del producto 1: " + litros_cod1);
		
		JOptionPane.showMessageDialog(null, "Facturas mayores a 600: " + mas_600);
		
		

	}

}
