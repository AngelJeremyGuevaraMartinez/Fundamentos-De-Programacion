package tarea14;

import java.io.*;

import javax.swing.*;

public class boletin02_20_b_dowhile {
    public static void main(String[] args) {

        int i = 1;
        int n;
        double sueldo, sueldo_max = 0;

        n = Integer.parseInt(JOptionPane.showInputDialog("Numero de sueldos: "));

        if (n > 0) {
            do {

                sueldo = Double.parseDouble(JOptionPane.showInputDialog("Introduce sueldo: "));

                if (sueldo > sueldo_max) {
                    sueldo_max = sueldo;
                }

                i++;

            } while (i <= n);
        }

        JOptionPane.showMessageDialog(null, "El sueldo maximo es: " + sueldo_max);
    }
}