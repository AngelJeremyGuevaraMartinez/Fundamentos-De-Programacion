package tarea14;
import javax.swing.*;

public class boletin02_20_b_for {
    public static void main(String[] args) {

        int n;
        double sueldo, sueldo_max = 0;

        n = Integer.parseInt(JOptionPane.showInputDialog("Numero de sueldos: "));

        for (int i = 1; i <= n; i++) {

            sueldo = Double.parseDouble(JOptionPane.showInputDialog("Introduce sueldo: "));

            if (sueldo > sueldo_max) {
                sueldo_max = sueldo;
            }
        }

        JOptionPane.showMessageDialog(null, "El sueldo maximo es: " + sueldo_max);
    }
}