package tarea14;
import javax.swing.JOptionPane;

public class boletin02_20_b_while {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i, n;
		double sueldo, sueldo_max;
		sueldo_max = 0;
		n = Integer.parseInt(JOptionPane.showInputDialog("Numero de sueldos: "));
		i = 1;
		while (i <= n) {
			sueldo = Double.parseDouble(JOptionPane.showInputDialog("Introduce sueldo: "));
			if (sueldo > sueldo_max) {
				sueldo_max = sueldo;
			}
			i = i + 1;
		}
		JOptionPane.showMessageDialog(null, "El sueldo maximo es: " + sueldo_max);
		

	}

}
