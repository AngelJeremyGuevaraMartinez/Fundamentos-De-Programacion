package tarea14;
import java.io.*;

public class boletin02_21_a_dowhile {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int i = 1, num;
        boolean hay_negativo = false;

        do {

            System.out.println("Introduce numero: ");
            num = Integer.parseInt(br.readLine());

            if (num < 0) {
                hay_negativo = true;
            }

            i++;

        } while (i <= 10);

        if (hay_negativo) {
            System.out.println("Se ha introducido algun numero negativo");
        } else {
            System.out.println("No hay ningun numero negativo");
        }
    }
}