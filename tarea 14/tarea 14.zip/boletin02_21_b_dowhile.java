package tarea14;

import javax.swing.*;

public class boletin02_21_b_dowhile {
    public static void main(String[] args) {

        int i = 1, num;
        boolean hay_negativo = false;

        do {

            num = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce numero: ")
            );

            if (num < 0) {
                hay_negativo = true;
            }

            i++;

        } while (i <= 10);

        if (hay_negativo) {
            JOptionPane.showMessageDialog(null,
                    "Se ha introducido algun numero negativo");
        } else {
            JOptionPane.showMessageDialog(null,
                    "No hay ningun numero negativo");
        }
    }
}