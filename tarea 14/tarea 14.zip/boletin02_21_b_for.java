package tarea14;

import javax.swing.*;

public class boletin02_21_b_for {
    public static void main(String[] args) {

        int num;
        boolean hay_negativo = false;

        for (int i = 1; i <= 10; i++) {

            num = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce numero: ")
            );

            if (num < 0) {
                hay_negativo = true;
            }
        }

        if (hay_negativo) {
            JOptionPane.showMessageDialog(null,
                    "Se ha introducido algun numero negativo");
        } else {
            JOptionPane.showMessageDialog(null,
                    "No hay ningun numero negativo");
        }
    }
}