package tarea14;
import java.io.*;

public class boletin02_22_a_for {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int nota;
        boolean suspensos = false;

        for (int i = 1; i <= 5; i++) {

            System.out.println("Introduce nota (0 a 10): ");
            nota = Integer.parseInt(br.readLine());

            if (nota < 5) {
                suspensos = true;
            }
        }

        if (suspensos) {
            System.out.println("Hay alumnos suspensos");
        } else {
            System.out.println("No hay suspensos");
        }
    }
}