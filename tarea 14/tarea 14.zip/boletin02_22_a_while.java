package tarea14;

import java.io.*;

public class boletin02_22_a_while {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int i = 1, nota;
        boolean suspensos = false;

        while (i <= 5) {

            System.out.println("Introduce nota (0 a 10): ");
            nota = Integer.parseInt(br.readLine());

            if (nota < 5) {
                suspensos = true;
            }

            i++;
        }

        if (suspensos) {
            System.out.println("Hay alumnos suspensos");
        } else {
            System.out.println("No hay suspensos");
        }
    }
}