package tarea14;
import javax.swing.*;

public class boletin02_22_b_dowhile {
    public static void main(String[] args) {

        int i = 1, nota;
        boolean suspensos = false;

        do {

            nota = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce nota (0 a 10): ")
            );

            if (nota < 5) {
                suspensos = true;
            }

            i++;

        } while (i <= 5);

        if (suspensos) {
            JOptionPane.showMessageDialog(null, "Hay alumnos suspensos");
        } else {
            JOptionPane.showMessageDialog(null, "No hay suspensos");
        }
    }
}