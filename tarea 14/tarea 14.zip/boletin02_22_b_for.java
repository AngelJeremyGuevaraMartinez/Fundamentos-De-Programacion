package tarea14;
import javax.swing.*;

public class boletin02_22_b_for {
    public static void main(String[] args) {

        int nota;
        boolean suspensos = false;

        for (int i = 1; i <= 5; i++) {

            nota = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce nota (0 a 10): ")
            );

            if (nota < 5) {
                suspensos = true;
            }
        }

        if (suspensos) {
            JOptionPane.showMessageDialog(null, "Hay alumnos suspensos");
        } else {
            JOptionPane.showMessageDialog(null, "No hay suspensos");
        }
    }
}