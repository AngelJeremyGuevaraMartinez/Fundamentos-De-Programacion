package tarea14;

import javax.swing.*;

public class boletin02_22_b_while {
    public static void main(String[] args) {

        int i = 1, nota;
        boolean suspensos = false;

        while (i <= 5) {

            nota = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce nota (0 a 10): ")
            );

            if (nota < 5) {
                suspensos = true;
            }

            i++;
        }

        if (suspensos) {
            JOptionPane.showMessageDialog(null, "Hay alumnos suspensos");
        } else {
            JOptionPane.showMessageDialog(null, "No hay suspensos");
        }
    }
}