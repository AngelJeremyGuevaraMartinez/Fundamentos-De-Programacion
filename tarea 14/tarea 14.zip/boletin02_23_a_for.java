package tarea14;
import java.io.*;

public class boletin02_23_a_for {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int num;
        boolean multiplo_3 = false;

        for (int i = 1; i <= 5; i++) {

            System.out.println("Introduce numero: ");
            num = Integer.parseInt(br.readLine());

            if (num % 3 == 0) {
                multiplo_3 = true;
            }
        }

        if (multiplo_3) {
            System.out.println("Hay multiplo de 3");
        } else {
            System.out.println("No existen multiplos de 3");
        }
    }
}