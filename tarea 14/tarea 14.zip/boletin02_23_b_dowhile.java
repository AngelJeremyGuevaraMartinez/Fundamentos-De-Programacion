package tarea14;

import javax.swing.*;

public class boletin02_23_b_dowhile {
    public static void main(String[] args) {

        int i = 1, num;
        boolean multiplo_3 = false;

        do {

            num = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce numero: ")
            );

            if (num % 3 == 0) {
                multiplo_3 = true;
            }

            i++;

        } while (i <= 5);

        if (multiplo_3) {
            JOptionPane.showMessageDialog(null, "Hay multiplo de 3");
        } else {
            JOptionPane.showMessageDialog(null, "No existen multiplos de 3");
        }
    }
}