package tarea14;

import javax.swing.*;

public class boletin02_23_b_for {
    public static void main(String[] args) {

        int num;
        boolean multiplo_3 = false;

        for (int i = 1; i <= 5; i++) {

            num = Integer.parseInt(
                    JOptionPane.showInputDialog("Introduce numero: ")
            );

            if (num % 3 == 0) {
                multiplo_3 = true;
            }
        }

        if (multiplo_3) {
            JOptionPane.showMessageDialog(null, "Hay multiplo de 3");
        } else {
            JOptionPane.showMessageDialog(null, "No existen multiplos de 3");
        }
    }
}